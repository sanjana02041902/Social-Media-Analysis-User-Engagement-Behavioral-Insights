WITH tag_details AS 
    (
    SELECT d.id AS user_id,
        tag_id,
        tag_name,
    COUNT(DISTINCT c.id) AS num_tags
    FROM tags a
    JOIN photo_tags b ON a.id = b.tag_id
    JOIN photos c ON c.id = b.photo_id
    JOIN users d ON d.id = c.user_id
    GROUP BY tag_id, tag_name, d.id
    ORDER BY user_id
    ),
    ranking_tags AS 
    (
    SELECT *,       
        DENSE_RANK() OVER (PARTITION BY user_id ORDER BY num_tags DESC) AS ranking
    FROM tag_details
    ),
    grouping_tags AS 
    (
    SELECT *
    FROM ranking_tags 
    WHERE ranking = 1
    )
    SELECT user_id, 
         GROUP_CONCAT(tag_name) AS all_tags 
    FROM grouping_tags  
    GROUP BY user_id;





