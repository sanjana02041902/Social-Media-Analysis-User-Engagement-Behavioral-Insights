SELECT 
        ROUND(AVG(num_tags), 2) AS avg_num_tags_per_post
        FROM 
    (
        SELECT 
            a.id,
            COALESCE(COUNT(tag_id), 0) AS num_tags
        FROM photos a
        LEFT JOIN photo_tags b 
            ON a.id = b.photo_id
        GROUP BY a.id
    ) 
        AS ab;

