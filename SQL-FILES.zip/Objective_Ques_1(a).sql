select count(*) as null_values_in_users 
from users 
where id is null or username is null or created_at is null;

select count(*) as null_values_in_tags 
from tags
where id is null or tag_name is null or created_at is null;

select count(*) as null_values_in_photos 
from photos 
where id is null or image_url is null or user_id is null or created_dat is null;

select count(*) as null_values_in_photo_tags 
from photo_tags 
where photo_id is null or tag_id is null;

select count(*) as null_values_in_follows 
from follows 
where follower_id is null or followee_id is null or created_at is null;

select count(*) as null_values_in_comments 
from comments 
where id is null or comment_text is null or user_id is null or photo_id is null or created_at is null;

select count(*) as null_values_in_likes 
from likes 
where user_id is null or photo_id is null or created_at is null;


