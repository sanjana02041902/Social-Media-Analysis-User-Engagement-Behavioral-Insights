    WITH count_likes AS 
    (
        SELECT 
            user_id,
            COUNT(*) AS num_likes 
        FROM likes 
        GROUP BY user_id
    ), 
    count_comments AS
    (
        SELECT 
            user_id,
            COUNT(*) AS num_comments 
        FROM comments 
        GROUP BY user_id 
    ), 
    count_photos AS
    (
        SELECT 
            user_id,
            COUNT(*) AS num_photos
        FROM photos 
        GROUP BY user_id 
    ) 

    SELECT 
        a.id, 
        a.username,
        COALESCE(num_likes, 0) AS num_likes,
        CASE 
            WHEN COALESCE(num_likes, 0) BETWEEN 1 AND 
                 ((SELECT MAX(num_likes) FROM count_likes) - (SELECT
MIN(num_likes) FROM count_likes)) / 3 
                 THEN "less likes"
            WHEN COALESCE(num_likes, 0) > 2 * 
                 ((SELECT MAX(num_likes) FROM count_likes) - (SELECT MIN(num_likes) FROM count_likes)) / 3 
                 THEN "high likes"
            WHEN COALESCE(num_likes, 0) = 0 
                 THEN "zero likes" 
            ELSE "medium likes" 
        END AS likes_segment,

        COALESCE(num_comments, 0) AS num_comments,
        CASE
            WHEN COALESCE(num_comments, 0) BETWEEN 1 AND 
                 ((SELECT MAX(num_comments) FROM count_comments) - (SELECT MIN(num_comments) FROM count_comments)) / 3 
                 THEN "low comments"
            WHEN COALESCE(num_comments, 0) > 2 * 
                 ((SELECT MAX(num_comments) FROM count_comments) - (SELECT MIN(num_comments) FROM count_comments)) / 3  
                THEN "High comments"
            WHEN COALESCE(num_comments, 0) = 0 
                THEN "zero comments"
            ELSE "medium comments" 
        END AS comments_segment,

        COALESCE(num_photos, 0) AS num_photos,
        CASE
            WHEN COALESCE(num_photos, 0) BETWEEN 1 AND 
                 ((SELECT MAX(num_photos) FROM count_photos) - (SELECT MIN(num_photos) FROM count_photos)) / 3 
                 THEN "low photos"
            WHEN COALESCE(num_photos, 0) > 2 * 
                 ((SELECT MAX(num_photos) FROM count_photos) - (SELECT MIN(num_photos) FROM count_photos)) / 3  
                 THEN "High photos"
            WHEN COALESCE(num_photos, 0) = 0 
                 THEN "zero photos"
            ELSE "medium photos" 
        END AS photos_segment

    FROM users a 
    LEFT JOIN count_likes b 
        ON a.id = b.user_id 
    LEFT JOIN count_comments c 
        ON a.id = c.user_id
    LEFT JOIN count_photos d 
        ON a.id = d.user_id;


