select id as user_id ,
count(*) as duplicate_values_in_users 
from users 
group by id
having duplicate_values_in_users>1;

select id as tag_id,
count(*) as duplicate_values_in_tags 
from tags 
group by id 
having duplicate_values_in_tags>1;

select id as photo_id,
count(*) as duplicate_values_in_photos 
from photos 
group by id 
having duplicate_values_in_photos>1;

select photo_id,
tag_id,
count(*) as duplicate_values_in_phototags 
from photo_tags 
group by photo_id,tag_id 
having duplicate_values_in_phototags >1;

select user_id,
photo_id,
count(*) as duplicate_values_in_likes 
from likes 
group by user_id,photo_id 
having duplicate_values_in_likes>1;

select id as comment_id ,
count(*) as duplicate_values_in_comments 
from comments 
group by id 
having duplicate_values_in_comments>1;

select follower_id
,followee_id,
count(*) as duplicate_values_in_follows 
from follows 
group by follower_id,followee_id 
having duplicate_values_in_follows >1;

