WITH post_data AS 
    (
        SELECT a.id AS post_id,
            d.username,
            COUNT(DISTINCT b.user_id) + COUNT(DISTINCT c.id) AS
user_post_activity
        FROM photos a
    JOIN likes b ON a.id = b.photo_id
    JOIN comments c ON a.id = c.photo_id
    JOIN users d ON a.user_id = d.id
    GROUP BY a.id
    ),
    photo_tag AS 
    (
        SELECT photo_id,
            tag_name
        FROM photo_tags a
    JOIN tags b ON b.id = a.tag_id
    )
        SELECT a.post_id,
            username,
            tag_name,
        user_post_activity
    FROM post_data a
    JOIN photo_tag b ON a.post_id = b.photo_id;
