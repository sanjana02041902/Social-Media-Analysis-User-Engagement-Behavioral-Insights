    SELECT 
    a.id, 
    a.username 
    FROM users a 
    LEFT JOIN likes b 
    ON a.id = b.user_id
    WHERE b.user_id IS NULL



