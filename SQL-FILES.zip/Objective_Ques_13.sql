    SELECT
        fb.followee_id AS original_follower, 
        fb.follower_id AS user_followed_back
        FROM follows fb
        JOIN follows orig
        ON fb.follower_id = orig.followee_id
        AND fb.followee_id = orig.follower_id
        AND fb.created_at > orig.created_at;










