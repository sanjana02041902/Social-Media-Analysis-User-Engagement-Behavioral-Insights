WITH user_likes AS 
    (
    SELECT 
        user_id,
        COUNT(*) AS num_likes 
    FROM likes 
    GROUP BY user_id
    ),
   
    user_comments AS 
    (
    SELECT 
        user_id,
        COUNT(id) AS num_comments 
    FROM comments 
    GROUP BY user_id
    ),
    user_posts AS 
    (
    SELECT 
        user_id,
        COUNT(id) AS num_posts
    FROM photos 
    GROUP BY user_id
    ),

    users_engagement AS 
    ( 
    SELECT 
        a.id,
        a.username,
        COALESCE(num_likes, 0) + COALESCE(num_comments, 0) + COALESCE(num_posts, 0) AS user_behaviour,
        COALESCE(num_likes, 0) + COALESCE(num_comments, 0) AS engagement
    FROM users a 
    LEFT JOIN user_likes b 
        ON a.id = b.user_id 
    LEFT JOIN user_comments c 
        ON a.id = c.user_id
    LEFT JOIN user_posts d 
        ON a.id = d.user_id
    )
    SELECT 
    *,
    CASE 
        WHEN engagement <= 
    (        
        (SELECT MAX(engagement) FROM users_engagement) - 
            (SELECT MIN(engagement) FROM users_engagement)
    ) / 3
        THEN 'low engagement'

    WHEN engagement >= 2 *  
    (        
        (SELECT MAX(engagement) FROM users_engagement) - 
            (SELECT MIN(engagement) FROM users_engagement)
    ) / 3 
        THEN 'high engagement'
    WHEN engagement BETWEEN 
    (  
         (SELECT MAX(engagement) FROM users_engagement) - 
           (SELECT MIN(engagement) FROM users_engagement)
    ) / 3 
        AND 2 * (
        (SELECT MAX(engagement) FROM users_engagement) -
            (SELECT MIN(engagement) FROM users_engagement)
    ) / 3 

    THEN 'mid engagement'
    END AS category
    FROM users_engagement;


