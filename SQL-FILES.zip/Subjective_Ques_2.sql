    select a.id,
    a.username,
    count(distinct b.user_id)+count(distinct c.id)+count(distinct d.id) as engagement 
    from users a 
    left join likes b on a.id=b.user_id
    left join comments c on a.id=c.user_id
    left join photos d
    on a.id=d.user_id 
    group by a.id,
    a.username
    having count(distinct b.user_id)+count(distinct c.id)+count(distinct d.id)=0;

