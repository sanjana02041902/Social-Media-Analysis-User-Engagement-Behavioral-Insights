WITH user_likes AS
    (
    SELECT 
        user_id, 
        COUNT(photo_id) AS num_likes 
    FROM likes 
    GROUP BY user_id
    ),
        user_comments AS 
    (
    SELECT 
        user_id, 
        COUNT(id) AS num_comments 
    FROM comments 
    GROUP BY user_id
    ),
        user_photos AS 
    (
    SELECT 
        user_id,
        COUNT(id) AS num_photos 
    FROM photos 
    GROUP BY user_id
    ),
    user_table AS
    (
    SELECT 
        a.id, 
        a.username,
        COALESCE(b.num_likes, 0) + COALESCE(c.num_comments, 0) + COALESCE(d.num_photos, 0) AS user_activity,
    COALESCE(b.num_likes, 0) + COALESCE(c.num_comments, 0) AS user_engagement,
        DENSE_RANK() OVER 
    (    
        ORDER BY 
        COALESCE(b.num_likes, 0) + COALESCE(c.num_comments, 0) + COALESCE(d.num_photos, 0) DESC, 
        COALESCE(b.num_likes, 0) + COALESCE(c.num_comments, 0) DESC
    ) AS loyal_customers_ranking
    FROM users a
    LEFT JOIN user_likes b 
        ON a.id = b.user_id
    LEFT JOIN user_comments c 
        ON a.id = c.user_id
    LEFT JOIN user_photos d 
        ON a.id = d.user_id
    )
    SELECT 
    * 
    FROM user_table 
    WHERE loyal_customers_ranking BETWEEN 1 AND 5;











