    with tag_likes as
    ( 
    select a.id as tag_id, 
    a.tag_name, 
    count(c.user_id) as num_likes 
    from tags a 
    left join photo_tags b on a.id=b.tag_id 
    left join likes c on b.photo_id=c.photo_id 
    group by tag_id,tag_name), 
    tag_comments as
    ( 
    select a.id as tag_id, 
    a.tag_name, 
    count(c.id) as num_comments 
    from tags a left join photo_tags b on a.id=b.tag_id 
    left join comments c on b.photo_id=c.photo_id 
    group by tag_id,tag_name), 
    tag_posts as
    ( 
    select a.id as tag_id, 
    a.tag_name, 
    count(c.id) as num_posts 
    from tags a 
    left join photo_tags b on a.id=b.tag_id 
    left join photos c on b.photo_id=c.id 
    group by tag_id,tag_name) 
    select a.tag_id, 
    a.tag_name, 
    (
    num_likes+num_comments)/num_posts as hashtag_engagement_rate , dense_rank()over(order by (num_likes+num_comments)/num_posts desc) as engagement_ranking 
    from tag_likes a 
    join tag_comments b on a.tag_id=b.tag_id 
    join tag_posts c on a.tag_id=c.tag_id


