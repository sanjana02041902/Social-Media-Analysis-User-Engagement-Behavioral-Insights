with post_posting as(
    select 
    a.id as post_id,
    a.user_id,
    d.username,
    a.created_dat as post_time,
    count(b.user_id)+count(c.id) as engagement 
    from photos a 
    left join likes b on a.id=b.photo_id
    left join comments c on a.id=c.photo_id 
    join users d on d.id=a.user_id
    group by a.id,
    a.user_id,
    a.created_dat,
    d.username)

    select hour(post_time) as post_hr,
    dayofweek(post_time) as post_day ,
    count(post_id) as num_posts,
    round(avg(engagement),0) as avg_engagement
      from post_posting group by post_hr,
    post_day;
