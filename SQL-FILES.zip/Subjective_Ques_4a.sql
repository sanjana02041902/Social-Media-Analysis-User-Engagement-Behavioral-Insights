select dayname(a.created_at) as day_of_week,
hour(a.created_at) as hour_of_day,
count(distinct d.user_id) as num_comments,
count(distinct c.user_id)  as num_likes,
count(distinct d.user_id)+count(distinct c.user_id) as engagement 
 from users a 
 left join photos b on a.id=b.user_id 
 left join likes c on b.id=c.photo_id 
 left join comments d on b.id=d.photo_id
group by dayname(a.created_at),
hour(a.created_at)  ;
