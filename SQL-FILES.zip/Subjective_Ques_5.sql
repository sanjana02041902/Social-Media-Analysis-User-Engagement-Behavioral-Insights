WITH user_followers AS 
    (
        SELECT 
        followee_id AS id,
        COUNT(followee_id) AS no_of_followers 
    FROM follows 
    GROUP BY followee_id
    ),
    user_likes AS 
    (
    SELECT 
        user_id,
        COUNT(*) AS num_likes
    FROM likes 
    GROUP BY user_id
    ),
    user_comments AS 
    (
    SELECT 
        user_id,
        COUNT(id) AS num_comments 
    FROM comments 
    GROUP BY user_id
    ),
    user_photos AS 
    (
    SELECT 
        user_id,
        COUNT(id) AS num_photos 
    FROM photos 
    GROUP BY user_id
    )
    SELECT 
    d.username,
    a.no_of_followers,
    b.num_likes,
    c.num_comments,
    ROUND((b.num_likes + c.num_comments) / num_photos, 2) AS engagement_rate,
    DENSE_RANK() OVER (ORDER BY b.num_likes + c.num_comments DESC) AS influencer_rating
    FROM user_followers a
    JOIN user_likes b 
    ON a.id = b.user_id
    JOIN user_comments c 
    ON a.id = c.user_id
    JOIN users d 
    ON a.id = d.id
    JOIN user_photos e 
    ON a.id = e.user_id;
