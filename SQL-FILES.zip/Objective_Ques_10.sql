    WITH user_post_attributes AS 
    (
    SELECT    
        u.id AS user_id,
        u.username,
        p.id AS post_id,
        COUNT(DISTINCT l.user_id) AS no_of_likes,
        COUNT(DISTINCT c.id) AS no_of_comments,
        COUNT(DISTINCT pt.tag_id) AS no_of_tags
    FROM users u
    JOIN photos p 
        ON u.id = p.user_id
    LEFT JOIN likes l 
    ON p.id = l.photo_id
    LEFT JOIN comments c 
         ON p.id = c.photo_id
         JOIN photo_tags pt 
         ON p.id = pt.photo_id 
         GROUP BY u.id, u.username, p.id
    )
    SELECT 
        user_id,
        username,
        SUM(no_of_likes) AS total_likes,
        SUM(no_of_comments) AS total_comments,
        SUM(no_of_tags) AS photo_tags
    FROM user_post_attributes
    GROUP BY user_id, username
    ORDER BY (SUM(no_of_likes) + SUM(no_of_comments) + SUM(no_of_tags)) DESC;








