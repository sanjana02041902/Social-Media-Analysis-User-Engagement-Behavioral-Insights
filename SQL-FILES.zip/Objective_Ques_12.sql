  WITH photo_num_likes AS 
    (
        SELECT 
        photo_id,
        COUNT(user_id) AS total_likes
        FROM likes
        GROUP BY photo_id
    ),
    photo_avg_likes AS 
    (  
        SELECT 
        photo_id,
        AVG(total_likes) AS avg_likes
        FROM photo_num_likes
        GROUP BY photo_id
    ),
    pic_with_highest_avg_likes AS 
    (
        SELECT 
        photo_id,
        DENSE_RANK() OVER (ORDER BY avg_likes DESC) AS pic_avg_like_rank
        FROM photo_avg_likes
    )
        SELECT 
        pt.photo_id,
        GROUP_CONCAT(t.tag_name) AS tags_of_the_post
        FROM photo_tags pt
        JOIN pic_with_highest_avg_likes ph 
        ON pt.photo_id = ph.photo_id
        JOIN tags t 
        ON pt.tag_id = t.id
        GROUP BY pt.photo_id, ph.pic_avg_like_rank
        ORDER BY ph.pic_avg_like_rank DESC;









