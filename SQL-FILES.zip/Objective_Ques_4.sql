WITH post_engagement AS 
    (
        SELECT 
            a.user_id,
            d.username,
            COUNT(DISTINCT b.user_id) AS num_likes,
            COUNT(DISTINCT c.id) AS num_comments,
            COUNT(DISTINCT a.id) AS num_photos,
            COUNT(DISTINCT b.user_id) + COUNT(DISTINCT c.id) AS
                engagement_on_posts
        FROM photos a
        LEFT JOIN likes b 
            ON a.id = b.photo_id
        LEFT JOIN comments c 
            ON a.id = c.photo_id
        JOIN users d 
            ON a.user_id = d.id
        GROUP BY a.user_id, d.username
        ),
        engagement_rate AS 
        (
        SELECT 
            *,
            CASE 
                WHEN num_photos = 0 THEN 0 
                ELSE (num_likes + num_comments) / num_photos 
            END AS engagement_rate
        FROM post_engagement
        )
        SELECT 
            *,
            DENSE_RANK() OVER (ORDER BY engagement_rate DESC) AS
engagement_rank
        FROM engagement_rate;
